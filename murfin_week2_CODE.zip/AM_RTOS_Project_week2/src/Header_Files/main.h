//***********************************************************************************
// Include files
//***********************************************************************************

#include <stdint.h>
#include <stdbool.h>

//***********************************************************************************
// defined files
//***********************************************************************************
#define	INFINITE_LOOP		true

// Micrium OS Task Defines
#define	MAIN_START_TASK_PRIO			21u
#define	MAIN_START_TASK_STK_SIZE		512u
#define	IDLE_TASK_PRIO					22u
#define	IDLE_TASK_STK_SIZE				64u
#define	SVC_PHYSICS_TASK_PRIO			1u
#define SVC_PHYSICS_TASK_STK_SIZE		512u
#define	LCD_GRAPHICS_TASK_PRIO			2u
#define LCD_GRAPHICS_TASK_STK_SIZE		512u
#define	MEASURE_CAPSENSE_TASK_PRIO		3u
#define MEASURE_CAPSENSE_TASK_STK_SIZE	512u
#define	BTN_IN_LED0_OUT_TASK_PRIO		4u
#define BTN_IN_LED0_OUT_TASK_STK_SIZE	512u
#define	LED1_OUT_TASK_PRIO				5u
#define LED1_OUT_TASK_STK_SIZE			512u
// Event Flag Definitions
#define EVENT_FLAGS_INITILZIED_CLEAR	0u
#define FLAG_PEND_FOREVER				0u
#define	FLAG_XMAX_VIOLATION				0x1 // b0 = "FLAG_XMAX_VIOLATION, b1 = "FLAG_PENDLM_FELL_VIOLATION"
#define	FLAG_PENDLM_FELL_VIOLATION		0x2
#define FLAG_BOTH_VIOLATIONS			(FLAG_XMAX_VIOLATION | FLAG_PENDLM_FELL_VIOLATION)
// Semaphore Definitions
#define	SEM_INITIALIZED_CLEAR			0u
#define	SEM_PEND_FOREVER				0u
// mutex definitions
#define	MUTEX_PEND_FOREVER				0u
// timer definitions
#define	TIMER_NO_DELAY					0u
#define	TIMER_100US_PERIOD				1u	// this value found by trial & error, may like to change it later
#define	TIMER_SVC_PHYSICS_PERIOD		TIMER_100US_PERIOD // Value = "Tphy" from task diagram
#define	TIMER_LCD_GRAPHICS_PERIOD		TIMER_100US_PERIOD // Value = "Tlcd" from task diagram
#define	TIMER_MEASURE_CAPSENSE_PERIOD	TIMER_100US_PERIOD // Value = "Tcap" from task diagram
#define	TIMER_LED1_BLINK_PERIOD			(TIMER_100US_PERIOD * 10) // 1Hz for xmax violation led1 blink routine
// MsgQ definitions
#define	BTN_IN_LED0_OUT_MAX_MSGQ_QTY	16u
#define	MSGQ_PEND_FOREVER				0u

// random definitions
#define VIOLATION_PENDULUM_FELL			90u	// violation value for theta
#define VIOLATION_XMIN					0u	// TODO figure out this value
#define VIOLATION_XMAX					0u  // TODO figure out this value
#define	SLIDER_SOFT_LEFT_FORCE			0u	// TODO figure out this value
#define SLIDER_HARD_LEFT_FORCE			0u	// TODO figure out this value
#define	SLIDER_SOFT_RIGHT_FORCE			0u	// TODO figure out this value
#define SLIDER_HARD_RIGHT_FORCE			0u	// TODO figure out this value
#define SLIDER_NO_FORCE					0u	// force value - no input to capsense
#define FORCE_GAIN_NONE					1u
#define FORCE_GAIN_ADJUST_VALUE			1u	// TODO figure out this value
#define	FORCE_GAIN_MAX_VALUE			6969u	// TODO figure out this value

// Application Data Structs Definitions
/**
 * @brief
 * "Pendulum Parameters" data struct.  Holds all varying
 * parameters of application "pendulum/rod".
 *
 * @note
 * This data struct is at the center of this project, and will be
 * read from or written to by four different tasks, so mutex will
 * be used.
 *
 */
typedef struct PendulumParams
{
	// Current rod base (x,y) coordinates (signed)
	int32_t		pendulumBaseX;
	// Current rod angle "theta" (signed)
	int8_t 		pendulumTheta;
	// Current Force Gain Coefficient (value adjusted w/buttons)
	uint16_t 	pendulumForceGain;
	// Current Force on Base (signed)
	int32_t 	pendulumForce;
} PendulumParams;

typedef enum pressedButton
{
	none,
	btn0,
	btn1
} pressedButton;

/**
 * @brief
 * "Button Message" data struct.  Simply holds which button was pushed, 0 or 1.
 *
 * @note
 * Used by "ButtonInLED0OutMsgQ" to pass pushed button data from GPIO ISR to
 * ButtonInLED0OutTask.
 *
 */
typedef struct ButtonMesssage
{
	pressedButton button;
} ButtonMessage;



//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// function prototypes
//***********************************************************************************
void postBtnMsgQ(pressedButton btn);
void initRodParams(void);
